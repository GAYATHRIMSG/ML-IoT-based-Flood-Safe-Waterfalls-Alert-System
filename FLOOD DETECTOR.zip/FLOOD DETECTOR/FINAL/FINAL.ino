#include <ESP8266WiFi.h>
#include <FirebaseESP8266.h>

// Pin definitions
const int flowSensorPin = D1;  // GPIO5
const int buzzerPin = D2;      // GPIO4
const int redLEDPin = D5;      // GPIO14
const int greenLEDPin = D6;    // GPIO12
const int blueLEDPin = D7;     // GPIO13

// WiFi credentials
#define WIFI_SSID "Airtel_prak_7199"
#define WIFI_PASSWORD "air96196"

// Firebase credentials
#define FIREBASE_HOST "my-water-flow-project-f1f53-default-rtdb.firebaseio.com"
#define FIREBASE_AUTH "AIzaSyDY4J3cGZq2OoV_hftSvyYdiNiZyzNai7E"

FirebaseData firebaseData;
FirebaseAuth auth;
FirebaseConfig config;

volatile int pulseCount = 0;    // Pulse count
unsigned long lastTime = 0;     // Last time for timing the loop
unsigned long interval = 1000;  // Interval to calculate flow (1 second)

String buzzerState = "off";
String greenLEDState = "off";
String redLEDState = "off";
float flowRate = 0.0;

void IRAM_ATTR pulseCounter() {
  pulseCount++;  // Increment pulse count on rising edge
}

void setup() {
  Serial.begin(115200);

  // Initialize Pins
  pinMode(flowSensorPin, INPUT);
  pinMode(buzzerPin, OUTPUT);
  pinMode(redLEDPin, OUTPUT);
  pinMode(greenLEDPin, OUTPUT);
  pinMode(blueLEDPin, OUTPUT);

  digitalWrite(buzzerPin, LOW);
  digitalWrite(redLEDPin, LOW);
  digitalWrite(greenLEDPin, LOW);
  digitalWrite(blueLEDPin, LOW);

  // Connect to WiFi
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  while (WiFi.status() != WL_CONNECTED) {
    delay(1000);
    Serial.println("Connecting to WiFi...");
  }
  Serial.println("Connected to WiFi");

  // Setup Firebase
  config.host = FIREBASE_HOST;
  config.signer.tokens.legacy_token = FIREBASE_AUTH;
  Firebase.begin(&config, &auth);
  Firebase.reconnectWiFi(true);

  // Attach interrupt
  attachInterrupt(digitalPinToInterrupt(flowSensorPin), pulseCounter, RISING);

  Serial.println("Setup complete. Waiting for pulses...");
}

void loop() {
  unsigned long currentTime = millis();

  if (currentTime - lastTime >= interval) {
    detachInterrupt(digitalPinToInterrupt(flowSensorPin));  // Temporarily detach interrupt

    Serial.print("Pulse Count: ");
    Serial.println(pulseCount);

    flowRate = (pulseCount / 7.5);  // Assuming 7.5 pulses per ml

    Serial.print("Flow Rate: ");
    Serial.print(flowRate);
    Serial.println(" ml/sec");

    // Buzzer and LED logic
    if (flowRate > 5) {
      digitalWrite(buzzerPin, HIGH);
      buzzerState = "on";
      Serial.println("Buzzer ON");
    } else {
      digitalWrite(buzzerPin, LOW);
      buzzerState = "off";
      Serial.println("Buzzer OFF");
    }

    if (flowRate > 0.5) {
      digitalWrite(redLEDPin, HIGH);
      digitalWrite(greenLEDPin, LOW);
      digitalWrite(blueLEDPin, LOW);
      redLEDState = "on";
      greenLEDState = "off";
      Serial.println("High Flow - Red LED ON");
      Serial.println("......................Packet received from TX-LoRA........................");
      Serial.println("......................Data sent to Firebase.........................");
    } else {
      digitalWrite(redLEDPin, LOW);
      digitalWrite(greenLEDPin, HIGH);
      digitalWrite(blueLEDPin, LOW);
      redLEDState = "off";
      greenLEDState = "on";
      Serial.println("Normal Flow - Green LED ON");
      Serial.println("......................Packet received from TX-LoRA........................");
      Serial.println("......................Data sent to Firebase.........................");
    }

    // Send data to Firebase
    Firebase.setFloat(firebaseData, "/flowRate", flowRate);
    Firebase.setString(firebaseData, "/buzzerState", buzzerState);
    Firebase.setString(firebaseData, "/greenLEDState", greenLEDState);
    Firebase.setString(firebaseData, "/redLEDState", redLEDState);

    pulseCount = 0;
    lastTime = currentTime;

    attachInterrupt(digitalPinToInterrupt(flowSensorPin), pulseCounter, RISING);
  }
}
