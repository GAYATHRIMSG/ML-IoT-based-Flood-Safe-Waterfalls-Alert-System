#include <SPI.h>
#include <LoRa.h>
#include <ESP8266WiFi.h>
#include <FirebaseESP8266.h>

#define WIFI_SSID "Airtel_prak_7199"
#define WIFI_PASSWORD "air96196"
#define FIREBASE_HOST "my-water-flow-project-f1f53-default-rtdb.firebaseio.com"
#define FIREBASE_AUTH "l0oilDYsbHpAJ9iNXQgPzhGQNG4fsqS5docznzaY"

// Define Firebase objects
FirebaseData firebaseData;
FirebaseConfig config;
FirebaseAuth auth;

// LoRa module connections
#define SCK 14   // D5
#define MISO 12  // D6
#define MOSI 13  // D7
#define NSS 15   // D8
#define DIO0 4   // D2 (GPIO4)

void setup() {
    Serial.begin(115200);
    delay(3000);  // Allow ESP8266 to stabilize

    // Connect to WiFi
    connectWiFi();
    
    // Firebase Setup
    config.host = FIREBASE_HOST;
    config.signer.tokens.legacy_token = FIREBASE_AUTH;
    Firebase.begin(&config, &auth);
    Firebase.reconnectWiFi(true);

    // Initialize LoRa module
    Serial.println("Initializing LoRa...");
    SPI.begin();
    LoRa.setPins(NSS, DIO0);
    if (!LoRa.begin(433E6)) {  
        Serial.println("LoRa init failed! Check wiring.");
        while (1);  // Stay in this loop if LoRa initialization fails
    }
    Serial.println("LoRa Receiver Initialized.");
}

void loop() {
    int packetSize = LoRa.parsePacket();
    if (packetSize) {
        Serial.print("Received packet: ");
        String receivedData = "";

        while (LoRa.available()) {
            receivedData += (char)LoRa.read();
        }
        Serial.println(receivedData);

        // Send received data to Firebase
        if (Firebase.setString(firebaseData, "/LoRaData", receivedData)) {
            Serial.println("Data sent to Firebase successfully.");
        } else {
            Serial.println("Firebase Error: " + firebaseData.errorReason());
        }
    }

    yield();  // Prevent watchdog reset
}

// Function to handle WiFi connection with timeout
void connectWiFi() {
    Serial.print("Connecting to WiFi");
    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
    unsigned long startMillis = millis();
    while (WiFi.status() != WL_CONNECTED) {
        if (millis() - startMillis > 20000) {  // Timeout after 20 seconds
            Serial.println("\nWiFi connection failed! Rebooting...");
            ESP.restart();  // Restart if WiFi fails
        }
        Serial.print(".");
        delay(1000);
        yield();  // Prevent watchdog reset
    }
    Serial.println("\nConnected to WiFi");
}
