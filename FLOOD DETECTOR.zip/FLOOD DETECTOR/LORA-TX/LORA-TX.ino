#include <SPI.h>
#include <LoRa.h>

// LoRa Module Connections
#define SS    D8   // NSS (Chip Select)
#define DIO0  D4   // IRQ (Interrupt)

// SPI Connections (ESP8266 uses fixed hardware SPI)
#define SCK   D5   // Clock
#define MISO  D6   // Master In
#define MOSI  D7   // Master Out

// Sensor and Actuator Connections
#define FLOW_SENSOR D1  // Water Flow Sensor
#define BUZZER      D2  // Buzzer
#define RED_LED     D0  // Red LED
#define GREEN_LED   D3  // Green LED

volatile int pulseCount = 0;
unsigned long lastTime = 0;
const unsigned long interval = 1000;  // 1-second interval
float flowRate = 0.0;
bool buzzerState = false;
bool redLEDState = false;
bool greenLEDState = false;

// Interrupt Service Routine for Water Flow Sensor
void IRAM_ATTR pulseCounter() {
  pulseCount++;
}

void setup() {
  Serial.begin(115200);

  // Initialize Pins
  pinMode(FLOW_SENSOR, INPUT);
  pinMode(BUZZER, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);

  // Default OFF states
  digitalWrite(BUZZER, LOW);
  digitalWrite(RED_LED, LOW);
  digitalWrite(GREEN_LED, LOW);

  // Attach Interrupt for Water Flow Sensor
  attachInterrupt(digitalPinToInterrupt(FLOW_SENSOR), pulseCounter, RISING);

  // Start SPI (FIXED FOR ESP8266)
  SPI.begin();  // ✅ Correct for ESP8266

  // Initialize LoRa (Without Reset)
  LoRa.setSPI(SPI);
  LoRa.setPins(SS, DIO0);
  if (!LoRa.begin(433E6)) {
    Serial.println("LoRa init failed! Check wiring.");
    while (1);
  }

  Serial.println("LoRa Sender Initialized.");
}

void loop() {
  unsigned long currentTime = millis();

  if (currentTime - lastTime >= interval) {
    detachInterrupt(digitalPinToInterrupt(FLOW_SENSOR));

    // Calculate flow rate
    flowRate = (pulseCount / 7.5);
    Serial.printf("Flow Rate: %.2f ml/sec\n", flowRate);

    // Determine alert conditions
    buzzerState = (flowRate > 5);
    redLEDState = (flowRate > 0.5);
    greenLEDState = !redLEDState;

    // Apply LED and Buzzer states
    digitalWrite(BUZZER, buzzerState);
    digitalWrite(RED_LED, redLEDState);
    digitalWrite(GREEN_LED, greenLEDState);

    // Log Status
    Serial.printf("Buzzer: %s | Red LED: %s | Green LED: %s\n",
                  buzzerState ? "ON" : "OFF",
                  redLEDState ? "ON" : "OFF",
                  greenLEDState ? "ON" : "OFF");

    // Send Data via LoRa
    LoRa.beginPacket();
    LoRa.printf("%.2f,%d,%d,%d", flowRate, buzzerState, redLEDState, greenLEDState);
    LoRa.endPacket();

    Serial.println("LoRa Data Sent!");

    // Reset Flow Sensor Counter
    pulseCount = 0;
    lastTime = currentTime;
    attachInterrupt(digitalPinToInterrupt(FLOW_SENSOR), pulseCounter, RISING);
  }
}
