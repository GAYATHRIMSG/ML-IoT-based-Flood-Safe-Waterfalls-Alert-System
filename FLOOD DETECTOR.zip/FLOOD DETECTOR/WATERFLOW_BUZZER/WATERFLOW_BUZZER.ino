// Pins
const int flowSensorPin = D6;
const int buzzerPin = D7;  // Example buzzer pin
const float alarmThreshold = 0.06;  // 1 milliliter per second in liters per minute

// Variables
volatile int flowPulseCount = 0;
unsigned long previousMillis = 0;
const unsigned long interval = 1000; // interval to count pulses (1 second)
float flowRate = 0.0;
float totalLiters = 0.0;

// ISR must be in IRAM
void ICACHE_RAM_ATTR countFlowPulses() {
  flowPulseCount++;
}

void setup() {
  // Initialize the serial communication
  Serial.begin(115200);

  // Set the flow sensor pin as an input
  pinMode(flowSensorPin, INPUT);
pinMode(buzzerPin, OUTPUT);
  
  // Attach an interrupt to the flow sensor pin
  attachInterrupt(digitalPinToInterrupt(flowSensorPin), countFlowPulses, RISING);
}

void loop() {
  unsigned long currentMillis = millis();

  // Check if the interval has passed
  if (currentMillis - previousMillis >= interval) {
    // Disable the interrupt to calculate the flow rate
    detachInterrupt(digitalPinToInterrupt(flowSensorPin));

    // Calculate the flow rate in liters per minute
    flowRate = (flowPulseCount / 7.5); // 7.5 pulses per second per liter/minute

    // Calculate the total liters
    totalLiters += (flowRate / 60.0); // Convert minutes to seconds

    // Print the flow rate and total liters
    Serial.print("Flow rate: ");
    Serial.print(flowRate);
    Serial.println(" L/min");

    Serial.print("Total: ");
    Serial.print(totalLiters);
    Serial.println(" L");

    // Reset the pulse count
    flowPulseCount = 0;

    // Reset the interval
    previousMillis = currentMillis;
     unsigned long currentMillis = millis();

  // Check if the interval has passed
  if (currentMillis - previousMillis >= interval) {
    // Disable the interrupt to calculate the flow rate
    detachInterrupt(digitalPinToInterrupt(flowSensorPin));

    // Calculate the flow rate in liters per minute
    flowRate = (flowPulseCount / 7.5); // 7.5 pulses per second per liter/minute

    // Calculate the total liters
    totalLiters += (flowRate / 60.0); // Convert minutes to seconds

    // Print the flow rate and total liters
    Serial.print("Flow rate: ");
    Serial.print(flowRate);
    Serial.println(" mL/sec");

    Serial.print("Total: ");
    Serial.print(totalmiliLiters);
    Serial.println(" L");

    // Check if flow rate exceeds the alarm threshold
    if (flowRate >= alarmThreshold) {
      digitalWrite(buzzerPin, HIGH);  // Turn on the buzzer
    } else {
      digitalWrite(buzzerPin, LOW);   // Turn off the buzzer
    }

    // Reset the pulse count
    flowPulseCount = 0;

    // Reset the interval
    previousMillis = currentMillis;


    // Re-enable the interrupt
    attachInterrupt(digitalPinToInterrupt(flowSensorPin), countFlowPulses, RISING);
  }

  }
}